import UIKit

var Collect : [String] = [ ]
print("You have \(Collect.count) bones")
if Collect.isEmpty {
    print("You have no bones")
} else {
    print("BONES")
}
var Collect2 : [String] = ["RedShells" , "RainbowShells"  ]
print("You have \(Collect2.count) shells")
if Collect2.isEmpty {
    print("You have no shells")
} else {
    print("SELL THE SHELLS")
}
var Collect3 : [String] = ["BatPlush" , "CatPlush" , "BearPlush" , "ReadPandaPlush" ]
print("You have \(Collect3.count) plushs")
if Collect3.isEmpty {
    print("You have plushs")
} else {
    print("Squish Squish")
}
var Collect4 : [String] = ["AdventureBooks" , "MysteryBooks" ]
print("You have \(Collect4.count) books")
if Collect4.isEmpty {
    print("Go return the books!")
} else {
    print("Collect more Books!")
}
